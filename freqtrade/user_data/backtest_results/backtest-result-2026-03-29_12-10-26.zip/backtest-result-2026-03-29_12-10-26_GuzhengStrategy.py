from __future__ import annotations

import os
from datetime import datetime

import numpy as np
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, stoploss_from_absolute


class GuzhengStrategy(IStrategy):
    """
    Mean-reversion envelope strategy centered on a long EMA.

    The strategy builds a dynamic multi-layer envelope around EMA(169).
    Entry direction is biased by trend strength, while position adjustment
    handles the main risk management through staged adds and trims.
    """

    INTERFACE_VERSION = 3

    can_short = True
    timeframe = "1m"
    process_only_new_candles = True
    startup_candle_count = 700

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    position_adjustment_enable = True
    max_entry_position_adjustment = 2
    use_custom_stoploss = True

    minimal_roi = {
        "0": 0.03,
        "30": 0.018,
        "120": 0.01,
    }

    stoploss = -0.12
    trailing_stop = False

    ma_period = 169
    bias_ma_period = 610
    fast_ma_period = 34
    atr_period = 21
    rsi_period = 14
    adx_period = 14

    # Allowed values: both, long_only, short_only.
    # `GUZHENG_DIRECTION_MODE` environment variable overrides this value.
    trade_direction_mode = "both"

    envelope_scales = (0.24, 0.38, 0.58, 0.82, 1.06, 1.34)
    entry_size_scales = (1.0, 0.45, 0.70)
    max_dca_multiplier = sum(entry_size_scales)

    plot_config = {
        "main_plot": {
            "ema_center": {"color": "#f5f1c5"},
            "env_upper_1": {"color": "#7db37d"},
            "env_upper_3": {"color": "#a3cfa3"},
            "env_upper_6": {"color": "#d9f0d9"},
            "env_lower_1": {"color": "#b37d7d"},
            "env_lower_3": {"color": "#cfa3a3"},
            "env_lower_6": {"color": "#f0d9d9"},
        },
        "subplots": {
            "Momentum": {
                "rsi": {"color": "#5ab1ef"},
                "adx": {"color": "#f6bd16"},
                "trend_score": {"color": "#9270ca"},
            }
        },
    }

    def _direction_mode(self) -> str:
        raw_mode = os.getenv("GUZHENG_DIRECTION_MODE", self.trade_direction_mode).strip().lower()
        mode_aliases = {
            "both": "both",
            "all": "both",
            "long": "long_only",
            "long_only": "long_only",
            "short": "short_only",
            "short_only": "short_only",
        }
        return mode_aliases.get(raw_mode, "both")

    def _allow_long(self) -> bool:
        return self._direction_mode() in {"both", "long_only"}

    def _allow_short(self) -> bool:
        return self._direction_mode() in {"both", "short_only"}

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["ema_center"] = ta.EMA(dataframe, timeperiod=self.ma_period)
        dataframe["ema_bias"] = ta.EMA(dataframe, timeperiod=self.bias_ma_period)
        dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=self.fast_ma_period)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=self.atr_period)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=self.rsi_period)
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe["plus_di"] = ta.PLUS_DI(dataframe, timeperiod=self.adx_period)
        dataframe["minus_di"] = ta.MINUS_DI(dataframe, timeperiod=self.adx_period)

        dataframe["center_slope"] = dataframe["ema_center"].pct_change(8).fillna(0.0)
        dataframe["bias_slope"] = dataframe["ema_bias"].pct_change(13).fillna(0.0)
        dataframe["center_gap"] = (
            (dataframe["close"] - dataframe["ema_center"]) / dataframe["ema_center"]
        ).replace([np.inf, -np.inf], 0.0)
        dataframe["regime_gap"] = (
            (dataframe["ema_center"] - dataframe["ema_bias"]) / dataframe["ema_bias"]
        ).replace([np.inf, -np.inf], 0.0)
        dataframe["rsi_delta"] = dataframe["rsi"].diff().fillna(0.0)

        smoothed_gap = dataframe["center_gap"].abs().ewm(span=55, adjust=False).mean()
        atr_component = (dataframe["atr"] / dataframe["ema_center"]).replace(
            [np.inf, -np.inf], 0.0
        )
        dataframe["vol_unit"] = (
            (smoothed_gap * 0.55) + (atr_component * 0.45)
        ).clip(lower=0.0025, upper=0.03)

        dataframe["trend_score"] = (
            np.where(dataframe["ema_fast"] > dataframe["ema_center"], 1.0, -1.0)
            + np.where(dataframe["ema_center"] > dataframe["ema_bias"], 1.0, -1.0)
            + np.where(
                dataframe["center_slope"] > 0.0005,
                1.0,
                np.where(dataframe["center_slope"] < -0.0005, -1.0, 0.0),
            )
            + np.where(dataframe["plus_di"] > dataframe["minus_di"], 1.0, -1.0)
            + np.where(
                dataframe["rsi"] > 52,
                1.0,
                np.where(dataframe["rsi"] < 48, -1.0, 0.0),
            )
        )

        dataframe["bias_long"] = (
            (dataframe["trend_score"] >= 2.0)
            & (dataframe["adx"] >= 14.0)
            & (dataframe["regime_gap"] > 0.0010)
            & (dataframe["bias_slope"] > -0.0002)
        ).astype(int)
        dataframe["bias_short"] = (
            (dataframe["trend_score"] <= -2.0)
            & (dataframe["adx"] >= 14.0)
            & (dataframe["regime_gap"] < -0.0010)
            & (dataframe["bias_slope"] < 0.0002)
        ).astype(int)
        dataframe["range_regime"] = (
            (dataframe["adx"] < 16.0)
            & (dataframe["regime_gap"].abs() < 0.0045)
            & (dataframe["center_slope"].abs() < 0.0007)
        ).astype(int)
        dataframe["trend_long_context"] = (
            (dataframe["range_regime"] == 0)
            & (dataframe["regime_gap"] > 0.0010)
            & (dataframe["bias_slope"] > -0.0002)
            & (dataframe["trend_score"] >= 2.0)
        ).astype(int)
        dataframe["trend_short_context"] = (
            (dataframe["range_regime"] == 0)
            & (dataframe["regime_gap"] < -0.0010)
            & (dataframe["bias_slope"] < 0.0002)
            & (dataframe["trend_score"] <= -2.0)
        ).astype(int)
        dataframe["bias_neutral"] = dataframe["range_regime"]

        for idx, scale in enumerate(self.envelope_scales, start=1):
            expansion = dataframe["vol_unit"] * scale
            dataframe[f"env_upper_{idx}"] = dataframe["ema_center"] * (1.0 + expansion)
            dataframe[f"env_lower_{idx}"] = dataframe["ema_center"] * (1.0 - expansion)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_short"] = 0

        long_reclaim = (
            (dataframe["low"] <= dataframe["env_lower_1"])
            & (dataframe["close"] >= dataframe["env_lower_1"])
            & (dataframe["rsi_delta"] >= 0.0)
        )
        short_reject = (
            (dataframe["high"] >= dataframe["env_upper_1"])
            & (dataframe["close"] <= dataframe["env_upper_1"])
            & (dataframe["rsi_delta"] <= 0.0)
        )

        long_pullback = (
            (dataframe["trend_long_context"] == 1)
            & long_reclaim
            & dataframe["rsi"].between(28, 55)
            & (dataframe["volume"] > 0)
        )
        long_range_reversion = (
            (dataframe["range_regime"] == 1)
            & (dataframe["low"] <= dataframe["env_lower_5"])
            & (dataframe["close"] > dataframe["env_lower_4"])
            & dataframe["rsi"].between(18, 30)
            & long_reclaim
            & (dataframe["volume"] > 0)
        )

        short_pullback = (
            (dataframe["trend_short_context"] == 1)
            & short_reject
            & dataframe["rsi"].between(45, 75)
            & (dataframe["volume"] > 0)
        )
        short_range_reversion = (
            (dataframe["range_regime"] == 1)
            & (dataframe["high"] >= dataframe["env_upper_5"])
            & (dataframe["close"] < dataframe["env_upper_4"])
            & dataframe["rsi"].between(70, 84)
            & short_reject
            & (dataframe["volume"] > 0)
        )

        if self._allow_long():
            dataframe.loc[long_pullback, ["enter_long", "enter_tag"]] = (
                1,
                "trend_pullback_long",
            )
            dataframe.loc[long_range_reversion, ["enter_long", "enter_tag"]] = (
                1,
                "range_reversion_long",
            )

        if self._allow_short():
            dataframe.loc[short_pullback, ["enter_short", "enter_tag"]] = (
                1,
                "trend_pullback_short",
            )
            dataframe.loc[short_range_reversion, ["enter_short", "enter_tag"]] = (
                1,
                "range_reversion_short",
            )

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "exit_long"] = 0
        dataframe.loc[:, "exit_short"] = 0

        exit_long_center = (
            (dataframe["close"] >= dataframe["ema_center"])
            & (dataframe["rsi"] >= 54)
            & (dataframe["volume"] > 0)
        )
        exit_long_stretch = (
            (dataframe["close"] >= dataframe["env_upper_1"])
            & (dataframe["rsi"] >= 66)
            & (dataframe["volume"] > 0)
        )
        exit_long_flip = (
            (dataframe["trend_score"] <= -3.0)
            & (dataframe["close"] >= dataframe["ema_center"] * 0.997)
            & (dataframe["volume"] > 0)
        )

        exit_short_center = (
            (dataframe["close"] <= dataframe["ema_center"])
            & (dataframe["rsi"] <= 46)
            & (dataframe["volume"] > 0)
        )
        exit_short_stretch = (
            (dataframe["close"] <= dataframe["env_lower_1"])
            & (dataframe["rsi"] <= 34)
            & (dataframe["volume"] > 0)
        )
        exit_short_flip = (
            (dataframe["trend_score"] >= 3.0)
            & (dataframe["close"] <= dataframe["ema_center"] * 1.003)
            & (dataframe["volume"] > 0)
        )

        dataframe.loc[
            exit_long_center | exit_long_stretch | exit_long_flip,
            ["exit_long", "exit_tag"],
        ] = (1, "mean_reversion_complete")
        dataframe.loc[
            exit_short_center | exit_short_stretch | exit_short_flip,
            ["exit_short", "exit_tag"],
        ] = (1, "mean_reversion_complete")

        return dataframe

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_stake: float,
        min_stake: float | None,
        max_stake: float,
        leverage: float,
        entry_tag: str | None,
        side: str,
        **kwargs,
    ) -> float:
        if (side == "long" and not self._allow_long()) or (side == "short" and not self._allow_short()):
            return 0.0

        stake = max_stake / self.max_dca_multiplier
        if self.config.get("stake_amount") != "unlimited":
            stake = proposed_stake / self.max_dca_multiplier

        if entry_tag and "range_reversion" in entry_tag:
            stake *= 0.75

        if min_stake is not None:
            stake = max(stake, min_stake)

        return min(stake, max_stake)

    def adjust_trade_position(
        self,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        min_stake: float | None,
        max_stake: float,
        current_entry_rate: float,
        current_exit_rate: float,
        current_entry_profit: float,
        current_exit_profit: float,
        **kwargs,
    ) -> float | None | tuple[float | None, str | None]:
        if trade.has_open_orders or not self.dp:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe is None or len(dataframe) < 2:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        previous_candle = dataframe.iloc[-2].squeeze()
        entry_tag = (getattr(trade, "enter_tag", "") or "").lower()
        range_trade = "range_reversion" in entry_tag

        trim_one = trade.stake_amount * (0.30 if not range_trade else 0.40)
        trim_two = trade.stake_amount * (0.45 if not range_trade else 0.35)

        if not trade.is_short:
            center_reached = last_candle["close"] >= last_candle["ema_center"]
            stretch_reached = last_candle["close"] >= last_candle["env_upper_1"]
        else:
            center_reached = last_candle["close"] <= last_candle["ema_center"]
            stretch_reached = last_candle["close"] <= last_candle["env_lower_1"]

        if (
            trade.nr_of_successful_exits == 0
            and current_profit > (0.010 if not range_trade else 0.007)
            and center_reached
            and (min_stake is None or trim_one >= min_stake)
        ):
            return -trim_one, "center_trim"

        if (
            trade.nr_of_successful_exits == 1
            and current_profit > (0.020 if not range_trade else 0.014)
            and stretch_reached
            and (min_stake is None or trim_two >= min_stake)
        ):
            return -trim_two, "outer_trim"

        filled_entries = trade.select_filled_orders(trade.entry_side)
        if not filled_entries:
            return None

        base_stake = filled_entries[0].stake_amount_filled
        if not base_stake:
            return None

        entry_count = trade.nr_of_successful_entries
        if range_trade and entry_count >= 2:
            return None
        if entry_count >= len(self.entry_size_scales):
            return None

        if not trade.is_short:
            stabilization = (
                (last_candle["close"] > previous_candle["close"])
                & (last_candle["close"] > last_candle["open"])
                & (last_candle["rsi"] > previous_candle["rsi"])
            )
            level_hit = (
                last_candle["low"] <= last_candle["env_lower_4"]
                if entry_count == 1
                else last_candle["low"] <= last_candle["env_lower_5"]
            )
            reclaimed_band = (
                last_candle["close"] > last_candle["env_lower_4"]
                if entry_count == 1
                else last_candle["close"] > last_candle["env_lower_5"]
            )
            oversold = last_candle["rsi"] < (32 if entry_count == 1 else 28)
            bias_ok = (
                (last_candle["trend_long_context"] == 1)
                or ((last_candle["range_regime"] == 1) and range_trade)
            )
            profit_gate = current_profit < (-0.018 if entry_count == 1 else -0.036)
        else:
            stabilization = (
                (last_candle["close"] < previous_candle["close"])
                & (last_candle["close"] < last_candle["open"])
                & (last_candle["rsi"] < previous_candle["rsi"])
            )
            level_hit = (
                last_candle["high"] >= last_candle["env_upper_4"]
                if entry_count == 1
                else last_candle["high"] >= last_candle["env_upper_5"]
            )
            reclaimed_band = (
                last_candle["close"] < last_candle["env_upper_4"]
                if entry_count == 1
                else last_candle["close"] < last_candle["env_upper_5"]
            )
            oversold = last_candle["rsi"] > (68 if entry_count == 1 else 72)
            bias_ok = (
                (last_candle["trend_short_context"] == 1)
                or ((last_candle["range_regime"] == 1) and range_trade)
            )
            profit_gate = current_profit < (-0.018 if entry_count == 1 else -0.036)

        if not (stabilization and level_hit and reclaimed_band and oversold and bias_ok and profit_gate):
            return None

        add_stake = base_stake * self.entry_size_scales[entry_count]
        if range_trade:
            add_stake *= 0.75
        if add_stake > max_stake:
            return None
        if min_stake is not None and add_stake < min_stake:
            return None

        return add_stake, f"band_{entry_count + 3}_add"

    def custom_stoploss(
        self,
        pair: str,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        after_fill: bool,
        **kwargs,
    ) -> float | None:
        if not self.dp:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        atr_buffer = float(last_candle["atr"] * 0.45)

        if trade.is_short:
            stop_price = float(last_candle["env_upper_6"] + atr_buffer)
            if current_profit > 0.018:
                stop_price = min(
                    stop_price, float(last_candle["ema_center"] + last_candle["atr"] * 0.55)
                )
            if current_profit > 0.035:
                stop_price = min(stop_price, float(current_rate + last_candle["atr"] * 0.90))
            if stop_price <= current_rate:
                return None
            return stoploss_from_absolute(
                stop_price,
                current_rate=current_rate,
                is_short=True,
                leverage=trade.leverage,
            )

        stop_price = float(last_candle["env_lower_6"] - atr_buffer)
        if current_profit > 0.018:
            stop_price = max(
                stop_price, float(last_candle["ema_center"] - last_candle["atr"] * 0.55)
            )
        if current_profit > 0.035:
            stop_price = max(stop_price, float(current_rate - last_candle["atr"] * 0.90))
        if stop_price >= current_rate:
            return None
        return stoploss_from_absolute(
            stop_price,
            current_rate=current_rate,
            is_short=False,
            leverage=trade.leverage,
        )
