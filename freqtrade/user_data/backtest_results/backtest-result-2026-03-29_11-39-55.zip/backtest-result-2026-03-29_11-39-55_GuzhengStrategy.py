from __future__ import annotations

from datetime import datetime

import numpy as np
import talib.abstract as ta
from pandas import DataFrame

from freqtrade.persistence import Trade
from freqtrade.strategy import IStrategy, stoploss_from_absolute


class GuzhengStrategy(IStrategy):
    """
    Mean-reversion envelope strategy centered on a long EMA.

    The strategy builds a dynamic multi-layer envelope around EMA(169).
    Entry direction is biased by trend strength, while position adjustment
    handles the main risk management through staged adds and trims.
    """

    INTERFACE_VERSION = 3

    can_short = True
    timeframe = "5m"
    process_only_new_candles = True
    startup_candle_count = 400

    use_exit_signal = True
    exit_profit_only = False
    ignore_roi_if_entry_signal = False

    position_adjustment_enable = True
    max_entry_position_adjustment = 2
    use_custom_stoploss = True

    minimal_roi = {
        "0": 0.03,
        "30": 0.018,
        "120": 0.01,
    }

    stoploss = -0.12
    trailing_stop = False

    ma_period = 169
    fast_ma_period = 34
    atr_period = 21
    rsi_period = 14
    adx_period = 14

    envelope_scales = (0.27, 0.44, 0.71, 0.93, 1.18, 1.39)
    entry_size_scales = (1.0, 0.70, 1.05)
    max_dca_multiplier = sum(entry_size_scales)

    plot_config = {
        "main_plot": {
            "ema_center": {"color": "#f5f1c5"},
            "env_upper_1": {"color": "#7db37d"},
            "env_upper_3": {"color": "#a3cfa3"},
            "env_upper_6": {"color": "#d9f0d9"},
            "env_lower_1": {"color": "#b37d7d"},
            "env_lower_3": {"color": "#cfa3a3"},
            "env_lower_6": {"color": "#f0d9d9"},
        },
        "subplots": {
            "Momentum": {
                "rsi": {"color": "#5ab1ef"},
                "adx": {"color": "#f6bd16"},
                "trend_score": {"color": "#9270ca"},
            }
        },
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe["ema_center"] = ta.EMA(dataframe, timeperiod=self.ma_period)
        dataframe["ema_fast"] = ta.EMA(dataframe, timeperiod=self.fast_ma_period)
        dataframe["atr"] = ta.ATR(dataframe, timeperiod=self.atr_period)
        dataframe["rsi"] = ta.RSI(dataframe, timeperiod=self.rsi_period)
        dataframe["adx"] = ta.ADX(dataframe, timeperiod=self.adx_period)
        dataframe["plus_di"] = ta.PLUS_DI(dataframe, timeperiod=self.adx_period)
        dataframe["minus_di"] = ta.MINUS_DI(dataframe, timeperiod=self.adx_period)

        dataframe["center_slope"] = dataframe["ema_center"].pct_change(8).fillna(0.0)
        dataframe["center_gap"] = (
            (dataframe["close"] - dataframe["ema_center"]) / dataframe["ema_center"]
        ).replace([np.inf, -np.inf], 0.0)

        smoothed_gap = dataframe["center_gap"].abs().ewm(span=55, adjust=False).mean()
        atr_component = (dataframe["atr"] / dataframe["ema_center"]).replace(
            [np.inf, -np.inf], 0.0
        )
        dataframe["vol_unit"] = (
            (smoothed_gap * 0.55) + (atr_component * 0.45)
        ).clip(lower=0.0025, upper=0.03)

        dataframe["trend_score"] = (
            np.where(dataframe["ema_fast"] > dataframe["ema_center"], 1.0, -1.0)
            + np.where(
                dataframe["center_slope"] > 0.0005,
                1.0,
                np.where(dataframe["center_slope"] < -0.0005, -1.0, 0.0),
            )
            + np.where(dataframe["plus_di"] > dataframe["minus_di"], 1.0, -1.0)
            + np.where(
                dataframe["rsi"] > 52,
                1.0,
                np.where(dataframe["rsi"] < 48, -1.0, 0.0),
            )
        )

        dataframe["bias_long"] = (
            (dataframe["trend_score"] >= 2.0) & (dataframe["adx"] >= 14.0)
        ).astype(int)
        dataframe["bias_short"] = (
            (dataframe["trend_score"] <= -2.0) & (dataframe["adx"] >= 14.0)
        ).astype(int)
        dataframe["bias_neutral"] = (
            (dataframe["bias_long"] == 0) & (dataframe["bias_short"] == 0)
        ).astype(int)

        for idx, scale in enumerate(self.envelope_scales, start=1):
            expansion = dataframe["vol_unit"] * scale
            dataframe[f"env_upper_{idx}"] = dataframe["ema_center"] * (1.0 + expansion)
            dataframe[f"env_lower_{idx}"] = dataframe["ema_center"] * (1.0 - expansion)

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "enter_long"] = 0
        dataframe.loc[:, "enter_short"] = 0

        long_reclaim = (dataframe["close"] > dataframe["open"]) | (
            dataframe["close"] > dataframe["close"].shift(1)
        )
        short_reject = (dataframe["close"] < dataframe["open"]) | (
            dataframe["close"] < dataframe["close"].shift(1)
        )

        long_pullback = (
            (dataframe["bias_long"] == 1)
            & (dataframe["close"] <= dataframe["env_lower_3"])
            & (dataframe["rsi"] < 45)
            & long_reclaim
            & (dataframe["volume"] > 0)
        )
        long_deep_reversion = (
            (dataframe["bias_neutral"] == 1)
            & (dataframe["close"] <= dataframe["env_lower_4"])
            & (dataframe["rsi"] < 38)
            & long_reclaim
            & (dataframe["volume"] > 0)
        )

        short_pullback = (
            (dataframe["bias_short"] == 1)
            & (dataframe["close"] >= dataframe["env_upper_3"])
            & (dataframe["rsi"] > 55)
            & short_reject
            & (dataframe["volume"] > 0)
        )
        short_deep_reversion = (
            (dataframe["bias_neutral"] == 1)
            & (dataframe["close"] >= dataframe["env_upper_4"])
            & (dataframe["rsi"] > 62)
            & short_reject
            & (dataframe["volume"] > 0)
        )

        dataframe.loc[long_pullback, ["enter_long", "enter_tag"]] = (1, "trend_pullback_long")
        dataframe.loc[
            long_deep_reversion, ["enter_long", "enter_tag"]
        ] = (1, "deep_reversion_long")
        dataframe.loc[
            short_pullback, ["enter_short", "enter_tag"]
        ] = (1, "trend_pullback_short")
        dataframe.loc[
            short_deep_reversion, ["enter_short", "enter_tag"]
        ] = (1, "deep_reversion_short")

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        dataframe.loc[:, "exit_long"] = 0
        dataframe.loc[:, "exit_short"] = 0

        exit_long_center = (
            (dataframe["close"] >= dataframe["ema_center"])
            & (dataframe["rsi"] >= 54)
            & (dataframe["volume"] > 0)
        )
        exit_long_stretch = (
            (dataframe["close"] >= dataframe["env_upper_1"])
            & (dataframe["rsi"] >= 66)
            & (dataframe["volume"] > 0)
        )
        exit_long_flip = (
            (dataframe["trend_score"] <= -3.0)
            & (dataframe["close"] >= dataframe["ema_center"] * 0.997)
            & (dataframe["volume"] > 0)
        )

        exit_short_center = (
            (dataframe["close"] <= dataframe["ema_center"])
            & (dataframe["rsi"] <= 46)
            & (dataframe["volume"] > 0)
        )
        exit_short_stretch = (
            (dataframe["close"] <= dataframe["env_lower_1"])
            & (dataframe["rsi"] <= 34)
            & (dataframe["volume"] > 0)
        )
        exit_short_flip = (
            (dataframe["trend_score"] >= 3.0)
            & (dataframe["close"] <= dataframe["ema_center"] * 1.003)
            & (dataframe["volume"] > 0)
        )

        dataframe.loc[
            exit_long_center | exit_long_stretch | exit_long_flip,
            ["exit_long", "exit_tag"],
        ] = (1, "mean_reversion_complete")
        dataframe.loc[
            exit_short_center | exit_short_stretch | exit_short_flip,
            ["exit_short", "exit_tag"],
        ] = (1, "mean_reversion_complete")

        return dataframe

    def custom_stake_amount(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_stake: float,
        min_stake: float | None,
        max_stake: float,
        leverage: float,
        entry_tag: str | None,
        side: str,
        **kwargs,
    ) -> float:
        stake = max_stake / self.max_dca_multiplier
        if self.config.get("stake_amount") != "unlimited":
            stake = proposed_stake / self.max_dca_multiplier

        if min_stake is not None:
            stake = max(stake, min_stake)

        return min(stake, max_stake)

    def adjust_trade_position(
        self,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        min_stake: float | None,
        max_stake: float,
        current_entry_rate: float,
        current_exit_rate: float,
        current_entry_profit: float,
        current_exit_profit: float,
        **kwargs,
    ) -> float | None | tuple[float | None, str | None]:
        if trade.has_open_orders or not self.dp:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(trade.pair, self.timeframe)
        if dataframe is None or len(dataframe) < 2:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        previous_candle = dataframe.iloc[-2].squeeze()

        trim_one = trade.stake_amount * 0.35
        trim_two = trade.stake_amount * 0.50

        if not trade.is_short:
            center_reached = last_candle["close"] >= last_candle["ema_center"]
            stretch_reached = last_candle["close"] >= last_candle["env_upper_1"]
        else:
            center_reached = last_candle["close"] <= last_candle["ema_center"]
            stretch_reached = last_candle["close"] <= last_candle["env_lower_1"]

        if (
            trade.nr_of_successful_exits == 0
            and current_profit > 0.010
            and center_reached
            and (min_stake is None or trim_one >= min_stake)
        ):
            return -trim_one, "center_trim"

        if (
            trade.nr_of_successful_exits == 1
            and current_profit > 0.022
            and stretch_reached
            and (min_stake is None or trim_two >= min_stake)
        ):
            return -trim_two, "outer_trim"

        filled_entries = trade.select_filled_orders(trade.entry_side)
        if not filled_entries:
            return None

        base_stake = filled_entries[0].stake_amount_filled
        if not base_stake:
            return None

        entry_count = trade.nr_of_successful_entries
        if entry_count >= len(self.entry_size_scales):
            return None

        if not trade.is_short:
            stabilization = last_candle["close"] >= previous_candle["close"]
            level_hit = (
                last_candle["close"] <= last_candle["env_lower_4"]
                if entry_count == 1
                else last_candle["close"] <= last_candle["env_lower_5"]
            )
            oversold = last_candle["rsi"] < (34 if entry_count == 1 else 30)
            profit_gate = current_profit < (-0.010 if entry_count == 1 else -0.022)
        else:
            stabilization = last_candle["close"] <= previous_candle["close"]
            level_hit = (
                last_candle["close"] >= last_candle["env_upper_4"]
                if entry_count == 1
                else last_candle["close"] >= last_candle["env_upper_5"]
            )
            oversold = last_candle["rsi"] > (66 if entry_count == 1 else 70)
            profit_gate = current_profit < (-0.010 if entry_count == 1 else -0.022)

        if not (stabilization and level_hit and oversold and profit_gate):
            return None

        add_stake = base_stake * self.entry_size_scales[entry_count]
        if add_stake > max_stake:
            return None
        if min_stake is not None and add_stake < min_stake:
            return None

        return add_stake, f"band_{entry_count + 3}_add"

    def custom_stoploss(
        self,
        pair: str,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        after_fill: bool,
        **kwargs,
    ) -> float | None:
        if not self.dp:
            return None

        dataframe, _ = self.dp.get_analyzed_dataframe(pair, self.timeframe)
        if dataframe is None or dataframe.empty:
            return None

        last_candle = dataframe.iloc[-1].squeeze()
        atr_buffer = float(last_candle["atr"] * 0.45)

        if trade.is_short:
            stop_price = float(last_candle["env_upper_6"] + atr_buffer)
            if current_profit > 0.018:
                stop_price = min(
                    stop_price, float(last_candle["ema_center"] + last_candle["atr"] * 0.55)
                )
            if current_profit > 0.035:
                stop_price = min(stop_price, float(current_rate + last_candle["atr"] * 0.90))
            if stop_price <= current_rate:
                return None
            return stoploss_from_absolute(
                stop_price,
                current_rate=current_rate,
                is_short=True,
                leverage=trade.leverage,
            )

        stop_price = float(last_candle["env_lower_6"] - atr_buffer)
        if current_profit > 0.018:
            stop_price = max(
                stop_price, float(last_candle["ema_center"] - last_candle["atr"] * 0.55)
            )
        if current_profit > 0.035:
            stop_price = max(stop_price, float(current_rate - last_candle["atr"] * 0.90))
        if stop_price >= current_rate:
            return None
        return stoploss_from_absolute(
            stop_price,
            current_rate=current_rate,
            is_short=False,
            leverage=trade.leverage,
        )
